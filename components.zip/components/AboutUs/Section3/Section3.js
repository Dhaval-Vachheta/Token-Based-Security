import React from 'react'
import './Section3.css'

export const Section3 = () => {
  return (
    <div className="section3aboutus">
      <section>
        <div className="aboutusTopdiv">
          Our goal is to establish fair  <br />
          investment opportunities as well as <br /> a quicker, safer, and easier trading system
        </div>
      </section>
      
    </div>
  )
}
