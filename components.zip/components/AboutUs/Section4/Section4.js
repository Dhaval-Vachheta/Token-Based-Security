import React from 'react'
import './Section4.css'

export const Section4 = () => {
  return (
    <div className="aboutusBottomdiv">
      <header>Get in touch</header>

      <span>
        Please contact us with any inquiries you may have about beginning to invest 
        <br />
        or listing your assets on the platform, and we would be pleased to assist you
      </span>
      <a href="mailto:info@terazo.network">
        <button>Send us an email.</button>
      </a>
    </div>
  )
}
