export const Data = [
  {
    question: 'What investments are made in the private market?',
    answer:
      'Real Estate, Venture Capital/Private equity funds, and shares of unlisted corporations are examples of investments that are not listed on an exchange.',
  },
  {
    question: 'Tokenization: What is it?',
    answer:
      'The process of fractionalizing and securitizing an asset into smaller pieces by digitally recording each component on a blockchain is known as Tokenization.',
  },
  {
    question: 'What are security tokens?',
    answer:
      'Traditional securities, such as real assets, stock, debt, and units of a fund that indicate beneficial interest, are represented digitally on a distributed ledger or blockchain by Security Tokens.',
  },
]
