import './Section2.css'
import img_product_step1 from '../../../assets/images/img/img_product_step1.png'
import img_register from '../../../assets/images/img/Register.JPG'
import img_product_step2 from '../../../assets/images/img/img_product_step2.png'
import img_explore from '../../../assets/images/img/Explore.JPG'
import img_product_step3 from '../../../assets/images/img/img_product_step3.png'
import img_invest from '../../../assets/images/img/Invest.JPG'

export const Slide = [
  {
    id: 1,
    logoimg: img_register,
    header: 'Send an invitation to join the team.',
    span: 'Check Eligibility >',
    subHeader: 'Give details for KYC validation.',
    img: img_product_step1,
    num: 1,
    title: 'Register',
  },
  {
    id: 2,
    logoimg: img_explore,
    header: 'Check out Dhaney’s platform for premium offerings in the private market.',

    img: img_product_step2,
    num: 2,
    title: 'Explore',
  },
  {
    id: 3,
    logoimg: img_invest,
    header:
      'Handle your assets with ease on our dashboard, earn money, and have the freedom to sell your tokens on our peer-to-peer exchange.',

    img: img_product_step3,
    num: 3,
    title: 'Invest & Trades',
  },
]
