import React from 'react'
import './Section1.css'
import imgPattern1 from '../../../assets/images/pattern/icn_pattern.svg'

export const Section1 = () => {
  return (
    <div className="howItWorksSec1">
      <div className="sec1Title">
        <img src={imgPattern1} alt="" />
        <header>
        It's now easier than ever <br /> to invest in private marketplaces
        </header>
        <span>Get started with Dhaney in 3 simple steps</span>
      </div>
    </div>
  )
}
