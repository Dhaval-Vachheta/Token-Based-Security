import React from 'react'
import './Section5.css'
import imgPattern from '../../../assets/images/pattern/img_pattern4.svg'
import { Data } from './Data'

export const Section5 = () => {
  return (
    <div className="section5hiw">
      <div className="sec5Header">
        <div>
          <header>The Future of Investing</header>
          <p>
          Using blockchain technology, we are able to provide you with
            <br />
            a secure and quick tokenization platform through
            <br/>
            the usage of {' '}
            <a
              href="https://polygon.technology/"
              target="_blank"
              rel="noopener noreferrer"
              style={{ textDecoration: 'none' }}
            >
              <span>Polygon</span>
            </a>{' '} 
            by blockchain Dhaney.
          </p>
        </div>
        <div className="sec5headerimg">
          <img src={imgPattern} alt="" />
        </div>
      </div>
      <div className="sec5hiwCards">
        {/* <br /> */}
        <header className="sec5hiwCardsHeader">Why Blockchain?</header>
        <div className="sec5hiwCard">
          {Data.map((i, index) => {
            return (
              <div className="blockchainCard" key={index}>
                <div className="img_gradient">
                  <img src={i.img} alt="" />
                </div>

                <div className="description">
                  <header> {i.title}</header>
                  <span> {i.span}</span>
                  <p>{i.para}</p>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
