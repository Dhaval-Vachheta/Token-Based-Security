export const Product = [
    {
        title:'Home',
        link:'/'
    },
    {
        title:'Why Invest?',
        link:'/'
    },
    {
        title:'How it works',
        link:'/howItWorks'
    },
]

export const Company = [
    {
        title:'About Us',
        link:'/aboutUs'
    },
    {
        title:'Team',
        link:''
    },
    {
        title:'Contact Us',
        link:'/contactUs'
    },
]

export const Resources = [
    {
        title:'Support',
        link:''
    },
    {
        title:'Blog',
        link:''
    },
    {
        title:'FAQs',
        link:''
    },
]

export const Legal = [
    {
        title:'Terms & conditions',
        link:''
    },
    {
        title:'Privacy Policy',
        link:'/'
    },
    {
        title:'Risk Conditions',
        link:'/howItWorks'
    },
]
