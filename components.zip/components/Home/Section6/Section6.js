import React from 'react'
import './Section6.css'

import { RequestInvite } from '../../RequestInvite/RequestInvite'

export const Section6 = () => {
  return (
    <div className="section6">
      <div className="bottomDiv">
        <header>Are you prepared to take part in the revolution in investing?</header>
        <RequestInvite />
      </div>
    </div>
  )
}
