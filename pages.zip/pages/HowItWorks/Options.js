export const Options=[
    {
        title:'Process',
        href:'#sec2'
    },
    {
        title:'Returns',
        href:'#sec3'
    },
    {
        title:'Tokenization',
        href:'#sec4'
    },
    {
        title:'Eligibility Criteria',
        href:'#sec6'
    },
    // {
    //     title:'FAQs',
    //     href:'#sec7'
    // },
]